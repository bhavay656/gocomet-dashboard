# GoComet Inbound Leads Dashboard

> **Replace `YOUR_GITHUB_USERNAME` in the deploy button URL below with your actual GitHub username after pushing.**

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https%3A%2F%2Fgithub.com%2FYOUR_GITHUB_USERNAME%2Fgocomet-dashboard&env=HUBSPOT_API_KEY&envDescription=HubSpot%20Private%20App%20token%20(Settings%20%E2%86%92%20Private%20Apps%20%E2%86%92%20create%20app%20%E2%86%92%20enable%20crm.objects.contacts.read)&project-name=gocomet-dashboard&repository-name=gocomet-dashboard)

Live dashboard that auto-fetches data from HubSpot on every visit. No manual exports, no static data.

## What it shows
- 16-month MoM inbound leads trend (ROW vs Americas)
- Segment breakdowns: Enterprise / Mid-Market / Startup/SMB
- Product source breakdown (Container Tracking, Port Congestion, Sailing Schedule, etc.)
- Funnel: Leads → Meetings → Deals/DM conversion ratios
- Filter by region, segment, and product

## Deploy to Vercel in 5 minutes

### Step 1 — Create a HubSpot Private App token

1. In HubSpot: go to **Settings → Integrations → Private Apps**
2. Click **Create a private app**
3. Name it `Vercel Dashboard`
4. Under **Scopes**, enable:
   - `crm.objects.contacts.read`
5. Click **Create app** → copy the token

### Step 2 — Push to GitHub

```bash
git init
git add .
git commit -m "Initial dashboard"
gh repo create gocomet-dashboard --private --push
```

### Step 3 — Deploy to Vercel

1. Go to [vercel.com](https://vercel.com) → **Add New Project**
2. Import your GitHub repo
3. In **Environment Variables**, add:
   - Key: `HUBSPOT_API_KEY`
   - Value: your token from Step 1
4. Click **Deploy**

Done. Your dashboard URL will be something like `https://gocomet-dashboard.vercel.app`

## Local development

```bash
cp .env.example .env.local
# Edit .env.local and add your HUBSPOT_API_KEY

npm install
npm run dev
# Open http://localhost:3000
```

## How data refresh works

- Data is cached server-side for **30 minutes**
- Each visit checks if the cache is stale; if so, it fetches fresh data from HubSpot
- No cron job needed — serverless function handles it automatically
- Cache resets on every new Vercel deployment

## Filters available

| Filter | Options |
|--------|---------|
| Region | All / ROW / Americas |
| Segment | All / Enterprise / Mid-Market / Startup/SMB |
| Product | All / Container Tracking / Port Congestion / Sailing Schedule / Freight Rates GFI / Freight Quotation / Vessel Tracking / Cargo Tracking / Other |

## Properties used from HubSpot

| Property | Purpose |
|----------|---------|
| `contact_us_form_submission_date` | Monthly bucketing |
| `inbound_lead_region` | ROW vs Americas split |
| `account_qualification__data_enrichment_` | Enterprise/Mid-Market/SMB segment |
| `response_bucket__seo_inside_sales_` | Meeting Set detection |
| `num_associated_deals` | Deal/DM conversion |
| `first_conversion_event_name` | Product source parsing |
